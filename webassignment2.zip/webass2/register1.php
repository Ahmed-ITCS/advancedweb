<?php
ini_set('display_errors', 1);
include('user.php');

$name = $_REQUEST['name'];
$name = strtolower($name);

$email = $_REQUEST['email'];
$email = strtolower($email);

$pass = $_REQUEST['pass'];
$pass = strrev($pass);
$pass = "!@#$%^&*()".$pass.")(*&^%$#@!";
$pass = md5($pass);

$user = new storeuser;

$user->setdb();
$existing = $user->check($name,$email);
if($existing->rowCount()!=0)
{
	header("location:login.php?msg='already exist user'");
	echo"error already exist\n";
}
else
{
	$user->signup($name,$email,$pass);
	header("location:login.php?msg='storemade successfully'");
}




?>