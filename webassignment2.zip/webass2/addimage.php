<?php

include('user.php');

$filename = $_FILES["file"]["name"];
$tempname = $_FILES["file"]["tmp_name"];
$actualname = $filename;
$folder = "files/".$filename.uniqid();

$user = new storeuser;
echo "hello";
$user->setdb();
session_start();
$id = $_SESSION['id'];
$user->addfile($folder,$id,$actualname);
//Get all the submitted data from the form
//$sql = "INSERT INTO image (filename) VALUES ('$filename')";
 
// Execute query
//mysqli_query($db, $sql);
 
// Now let's move the uploaded image into the folder: image
move_uploaded_file($tempname, $folder);
header("location:dashboard.php?msg='File uploaded successfully!'");



?>