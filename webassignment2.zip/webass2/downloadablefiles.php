<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>

</html>
<body>
	<table border = '1'>
		<th>Name</th>
		<th>downloads</th>
<?php
ini_set('display_errors', 1);
include('user.php');

echo "<a href='dashboard.php'>go to dashboard</a>";
$user = new storeuser;
$user->setdb();


$data = $user->getfiles();

foreach ($data as $key => $value) { ?>
	<tr>
		<td><?php echo $value['actualname'] ; ?></td>
		<td><?php echo $value['downloads'] ; ?></td>
		<td><a href="download.php?id='<?php echo $value['ID']?>'"><img src = "down.svg" /></a></td>
	</tr>


<?php
}




?>