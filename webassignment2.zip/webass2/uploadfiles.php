<?php

$msg = "";
if(isset($msg))
{
    $msg = $_REQUEST['msg'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-control" content="no-cache">
    <title>Document</title>
</head>
<body>
    <h1><?php echo $msg; ?></h1>
    
<a href="dashboard.php">go to dashboard</a>
    <h1>Upload file</h1>
    <form action="addimage.php" method="post" enctype="multipart/form-data">
        <table>
         <tr>
            <td>
                <label>file: </label>
            </td>
            <td>
                 <input type = "file" name = "file"/><br>
            </td>
        </tr>
        <tr>
            <td></td>
            <td><input type = "submit" value ="Submit" /></td>
        </tr>
        
        
        </table>
    </form>
</body>
</html>