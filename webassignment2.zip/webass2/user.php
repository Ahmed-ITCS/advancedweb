<?php
ini_set('display_errors', 1);

include('db.php');
class storeuser extends db{
    private $name;
    private $email;
    private $pass;
    public function check($t1,$t2)
    {
        $qu = "SELECT * FROM user WHERE Name = '$t1' or Email = '$t2'";
        return $this->con->query($qu);
    }
    public function signup($t1,$t2,$t3)
    {
        $this->name = $t1;
        $this->email = $t2;
        $this->pass = $t3;

        $qu = "INSERT into user(Name,Email,Password)values('$t1','$t2','$t3')";
        $this->con->query($qu);
        //$this->con->prepare($qu);
        
    }
    public function login($t1,$t2)
    {
        $this->email = $t2;
        $this->pass = $t3;

        $qu = "SELECT * from user WHERE email = '$t1' and password = '$t2'";
        return $this->con->query($qu);
        //$this->con->prepare($qu);
        
    }
    public function addfile($t1,$t2,$t3)
    {
        $query = "INSERT into files(name,userid,actualname) values('$t1','$t2','$t3')";
        $this->con->query($query);
    }

    public function getfiles()
    {
        $query = "SELECT * from files";
        return $this->con->query($query);
    }
    public function getfileeee($t)
    {
        $query = "SELECT * from files where ID = $t";
        return $this->con->query($query);
    }
    public function upd($t1)
    {
         echo $q = "UPDATE files SET downloads = downloads + 1 WHERE ID = $t1";
         $this->con->query($q);
    }
    
}



?>