<html>
	<meta http-equiv="Cache-control" content="no-cache">
</html>
<?php

class db{
	protected $con;
	public function setdb()
	{
		try{
			$this->con = new PDO("mysql: host=localhost;dbname=ass2","root","");
			//echo "Working\n";
		}
		catch(PDOException $e)
		{
			echo "Not Working\n";
		}
	}
}



?>