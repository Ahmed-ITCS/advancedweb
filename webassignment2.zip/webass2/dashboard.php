<?php
session_start();
if($_SESSION['id'] != "")
{
  
}
else
{

  header("location:login.php");
}
$msg = "";
if(isset($msg))
{
  $msg = $_GET['msg'];
}
else
{
  $msg="";
}

echo "Hello " . $_SESSION['name']."                                     ";

?>
<html>
<head>
  <style type="text/css">
div.square {
  border: solid 10px #f0f;
  width: 200px;
  height: 50px;
  border-color:black; 
  color: black;
}
div.square:hover{
    border: solid 10px #f0f;
  width: 200px;
  height: 50px;
  border-color:Red; 
  color: black;

}

div.square1 {
  border: solid 10px #f0f;
  width: 200px;
  height: 50px;
  border-color:black; 
  color: black;
}
div.square1:hover{
    border: solid 10px #f0f;
  width: 200px;
  height: 50px;
  border-color:Red; 
  color: black;

}

div.square2 {
  border: solid 10px #f0f;
  width: 200px;
  height: 50px;
  border-color:black; 
  color: black;
}
div.square2:hover{
    border: solid 10px #f0f;
  width: 200px;
  height: 50px;
  border-color:Red; 
  color: black;

}

  </style>
</head>
<a href="logout.php">logout</a>
<h1><?php echo $msg; ?></h1>
<div class="square">
  <a href ="downloadablefiles.php">Downloadable files</a>
</div>
<div class="square1">
  <a href ="uploadfiles.php">upload files</a>
</div>

</html>