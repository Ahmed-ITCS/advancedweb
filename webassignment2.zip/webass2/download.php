<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>

</html>
<body>
	<table border = '1'>
		<th>Name</th>
		<th>downloads</th>
<?php
ini_set('display_errors', 1);
include('user.php');
$id = $_REQUEST['id'];

$user = new storeuser;
$user->setdb();
$user->upd($id);

$data = $user->getfileeee($id);

foreach($data as $key => $value) {

	$file_path = $value['name'];
	$filename = $value['actualname'];
	header("Content-Type: application/octet-stream");
	header("Content-Transfer-Encoding: Binary");
	header("Content-disposition: attachment; filename=\"".$filename."\""); 
	echo readfile($file_path);
	header("downloadablefiles.php?ms='file downloaded'");
}





?>