<html>
<?php

include('user.php');
session_start();
$name = $_REQUEST['name'];
$id = $_SESSION['id'];

$user = new storeuser;
$user->setdb();
$data = $user->getdetail($id,$name);
if($data->rowCount() ==0)
{
	header("location:findproducts.php?msg='products not found'");
}
foreach ($data as $value) {
	echo "ID: ".$value['ID']."  <br>Name: ".$value['Name']."  <br>Code: ".$value['Code']."  <br>Quantity: ".$value['Quantity']."  <br>Category: ".$value['Category']."  <br>Brand: ".$value['Brand']."  <br>Description: ".$value['Description']."  <br>pic: ";
?>
<img src="<?php echo $value['pic']; ?>" />
<?php

}

?>

</html>