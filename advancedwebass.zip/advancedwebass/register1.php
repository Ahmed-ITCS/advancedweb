<html>
	<meta http-equiv="Cache-control" content="no-cache">
</html>
<?php

include('user.php');
$name = $_REQUEST['name'];
$name = strtolower($name);

$email = $_REQUEST['email'];
$email = strtolower($email);

$pass = $_REQUEST['pass'];
$pass = strrev($pass);
$pass = "!@#$%^&*()".$pass.")(*&^%$#@!";
$pass = md5($pass);

$type = $_REQUEST['type'];

$user = new storeuser;
$user->setdb();
$existing = $user->check($name,$email);
if($existing->rowCount()!=0)
{
	header("location:login.php?msg='already exist user'");
	echo"error alredy exist\n";
}
else
{
	$user->signup($name,$email,$pass,$type);
	header("location:login.php?msg='storemade successfully'");
}




?>