<?php

include('user.php');
$name = $_REQUEST['name'];
$code = $_REQUEST['code'];
$quantity = $_REQUEST['quantity'];
$category = $_REQUEST['category'];
$brand = $_REQUEST['brand'];
$description = $_REQUEST['Description'];


$filename = $_FILES["file"]["name"];
$tempname = $_FILES["file"]["tmp_name"];
$folder = $filename;

$user = new storeuser;
$user->setdb();
session_start();
$id = $_SESSION['id'];
$user->addproducts($name,$code,$quantity,$category,$brand,$description,$folder,$id);
//Get all the submitted data from the form
//$sql = "INSERT INTO image (filename) VALUES ('$filename')";
 
// Execute query
//mysqli_query($db, $sql);
 
// Now let's move the uploaded image into the folder: image
move_uploaded_file($tempname, $folder);
header("location:addproducts.php?msg='Product uploaded successfully!'");



?>