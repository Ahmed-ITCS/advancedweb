<?php

$id = $_GET['id'];

include('user.php');
$user = new storeuser;
$user->setdb();
if($user->deletee($id))
{
	header("location:dashboard.php?msg='deleted'");
}
else
{
	header("location:dashboard.php?msg='not deleted'");
	
}



?>