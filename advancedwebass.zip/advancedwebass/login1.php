<?php 

include('user.php');

$email = $_REQUEST['email'];
$email = strtolower($email);

$pass = $_REQUEST['pass'];
$pass = strrev($pass);
$pass = "!@#$%^&*()".$pass.")(*&^%$#@!";
$pass = md5($pass);

$temp="";
$user = new storeuser;
$user->setdb();
$existing = $user->check($temp,$email);
if($existing->rowCount()!=0)
{
	$user_data = $user->login($email,$pass);
	if($user_data->rowCount() == 0)
	{
		header("location:login.php?msg='Invalid user'");
	}
	else
	{
		session_start();
		echo"8888";
		foreach ($user_data as $value) {
			$_SESSION['name'] = $value['Name'];
			$_SESSION['id'] = $value['ID'];
			
		}
		header("location:dashboard.php");
	}
}
else
{	
	header("location:login.php?msg='USER NOT FOUND'");
}



?>