<?php

$msg = "";
if(isset($msg))
{
    $msg = $_REQUEST['msg'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-control" content="no-cache">
    <title>Document</title>
</head>
<body>
    <h1><?php echo $msg; ?></h1>
    <h1>Add Products</h1>
    <form action="addproducts1.php" method="post" enctype="multipart/form-data">
        <table>
        <tr>
            <td>
                <label>Product Name : </label>
            </td>
            <td>
                <input type="text" name="name" />
            </td>
        </tr>
        <tr>
            <td>
                <label>Product Code : </label>
            </td>
            <td>
                <input type="text" name="code"/>
            </td>
        </tr>
        <tr>
            <td>
                <label>Quantity : </label>
            </td>
            <td>
                 <input type = "num" name = "quantity"/><br>
            </td>
        </tr>
        <tr>
            <td>
                <label>Category : </label>
            </td>
            <td>
                 <select name="category">
                <option value="Tech">Tech</option>
                <option value="Home&Kitchen">Home&Kitchen</option>
                <option value="Baby">Kids</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>
                <label>Brand : </label>
            </td>
            <td>
                 <select name="brand">
                <option value="Dolce&Gabbana">Dolce&Gabbana</option>
                <option value="Varsace">Varsace</option>
                <option value="Baby">Baby</option>
                </select>
            </td>
        </tr>
         <tr>
            <td>
                <label>Product Image: </label>
            </td>
            <td>
                 <input type = "file" name = "file"/><br>
            </td>
        </tr>
        <tr>
            <td>
                <label>Product Description: </label>
            </td>
            <td>
                <textarea name="Description"></textarea>
            </td>
        </tr>
        <tr>
            <td></td>
            <td><input type = "submit" value ="Submit" /></td>
        </tr>
        
        
        </table>
    </form>
</body>
</html>