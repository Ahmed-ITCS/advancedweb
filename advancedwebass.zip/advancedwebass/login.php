<?php
session_start();
if($_SESSION['id'] != "")
{
	header("location:dashboard.php");
}
else
{
	
}
$msg = "";
if(isset($msg))
{
    $msg = $_REQUEST['msg'];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-control" content="no-cache">
    <title>Document</title>
 </head>
 <body>
<h1><?php echo $msg; ?></h1>
    <h1>Login</h1>
    <form action="login1.php" method="post">
        <table>
        <tr>
            <td>
                <label>Store email : </label>
            </td>
            <td>
                <input type="email" name="email"/>
            </td>
        </tr>
        <tr>
            <td>
                <label>Store Pass : </label>
            </td>
            <td>
                 <input type = "password" name = "pass"/><br>
            </td>
        </tr>
        <tr>
            <td></td>
            <td><input type = "submit" value ="Submit" /></td>
        </tr>
        
        
        </table>
    </form>
    </body>
</html>