<?php 
?>
<html>
<a href="dashboard.php">go to dashboard</a>
<table border="1">
	<tr>
		<th>ID</th>
		<th>Name</th>
		<th>Code</th>
		<th>Quantity</th>
		<th>Category</th>
		<th>Brand</th>
		<th>Description</th>
		<th>Pic</th>
		<th colspan="2">Operation</th>
	</tr>
<?php
include('user.php');
$user = new storeuser;
$user->setdb();
session_start();
$data = $user->viewproduct($_SESSION['id']);
foreach ($data as $value) 
{
?>
	
	<tr>
		<td><?php echo $value['ID'] ?></td>
		<td><?php echo $value['Name'] ?></td>
		<td><?php echo $value['Code'] ?></td>
		<td><?php echo $value['Quantity'] ?></td>
		<td><?php echo $value['Category'] ?></td>
		<td><?php echo $value['Brand'] ?></td>
		<td><?php echo $value['Description'] ?></td>
		<td><img src="<?php echo $value['pic']; ?>" width ="100" height="100"/></td>
		<td><button><a href="delete.php?id='<?php echo $value['ID'];?>'">delete</a></button></td>
		<td><button><a href="edit.php?id='<?php echo $value['ID'];?>'">edit</a></button></td>

	</tr>

<?php
	
echo "<br>";
}
?>

</table>	
</html>
