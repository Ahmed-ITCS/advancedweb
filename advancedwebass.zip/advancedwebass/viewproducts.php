<?php 
?>
<html>
<?php
include('user.php');
$user = new storeuser;
$user->setdb();
session_start();
$data = $user->viewproduct($_SESSION['id']);
foreach ($data as $value) {
	echo "ID: ".$value['ID']."  <br>Name: ".$value['Name']."  <br>Code: ".$value['Code']."  <br>Quantity: ".$value['Quantity']."  <br>Category: ".$value['Category']."  <br>Brand: ".$value['Brand']."  <br>Description: ".$value['Description']."  <br>pic: ";
	?>
	<img src="<?php echo $value['pic'];?>" alt="image"/> 
<?php
echo "<br>";
}
?>

	
</html>

<?php

if($existing->rowCount()!=0)
{
	$user_data = $user->login($email,$pass);
	if($user_data->rowCount() == 0)
	{
		header("location:login.php?msg='Invalid user'");
	}
	else
	{
		session_start();
		echo"8888";
		foreach ($user_data as $value) {
			$_SESSION['name'] = $value['Name'];
			$_SESSION['id'] = $value['ID'];
			
		}
		header("location:dashboard.php");
	}
}
else
{	
	header("location:login.php?msg='USER NOT FOUND'");
}



?>