<html>
    <meta http-equiv="Cache-control" content="no-cache">
</html>
<?php
include('db.php');
class storeuser extends db{
    private $name;
    private $email;
    private $pass;
    private $type;
    public function check($t1,$t2)
    {
        $qu = "SELECT * FROM store WHERE name = '$t1' or email = '$t2'";
        return $this->con->query($qu);
    }
    public function signup($t1,$t2,$t3,$t4)
    {
        $this->name = $t1;
        $this->email = $t2;
        $this->pass = $t3;
        $this->type = $t4;

        $qu = "INSERT into store(name,email,password,type)values('$t1','$t2','$t3','$t4')";
        $this->con->query($qu);
        //$this->con->prepare($qu);
        
    }
    public function login($t1,$t2)
    {
        $this->email = $t2;
        $this->pass = $t3;

        $qu = "SELECT * from store WHERE email = '$t1' and password = '$t2'";
        return $this->con->query($qu);
        //$this->con->prepare($qu);
        
    }
    public function addproducts($t1,$t2,$t3,$t4,$t5,$t6,$t7,$t8)
    {
        $query = "INSERT into product(Name,Code,Quantity,Category,Brand,Description,pic,userid) values('$t1','$t2','$t3','$t4','$t5','$t6','$t7','$t8')";
        $this->con->query($query);
    }
    public function viewproduct($t1)
    {
        $query = "SELECT * from product where userid = '$t1'";
        return $this->con->query($query);
    }
    public function getdetail($t1,$t2)
    {
        $query = "SELECT * from product where userid = '$t1' and name ='$t2'";
        return $this->con->query($query);   
    }



}



?>