-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Mar 25, 2023 at 07:03 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adwebbass`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ID` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Code` varchar(30) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Category` varchar(30) NOT NULL,
  `Brand` varchar(30) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `pic` text NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ID`, `Name`, `Code`, `Quantity`, `Category`, `Brand`, `Description`, `pic`, `userid`) VALUES
(4, 'Eleanor Emerson', 'Nihil nobis sed culp', 162, 'Home&Kitchen', 'Dolce&Gabbana', 'Iste blanditiis occa', 'ahmed and family national ID.jpeg', 1),
(5, 'Shelly Barker', 'Ut ipsum iste enim ', 601, 'Baby', 'Dolce&Gabbana', 'Nemo sint exercitati', 'ahmed and family national ID.jpeg', 1),
(6, 'Scott Cantrell', 'In amet amet molli', 351, 'Tech', 'Dolce&Gabbana', 'Consequuntur tempora', '', 6),
(7, 'Peter Norris', 'Soluta qui est repre', 713, 'Baby', 'Varsace', 'Dolorem nihil suscip', '', 6),
(8, 'Kasper Kirby', 'Esse nihil exercita', 873, 'Home&Kitchen', 'Baby', 'Ut et non magna quia', '', 6);

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `ID` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` text NOT NULL,
  `type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`ID`, `Name`, `Email`, `Password`, `type`) VALUES
(1, 'madonna reeves', 'gofakez@mailinator.com', 'bcad905cdcfcc99afb999f08b4ad263a', 'regular'),
(2, 'stephen raymond', 'zerevomu@mailinator.com', 'bcad905cdcfcc99afb999f08b4ad263a', 'regular'),
(3, 'sarah ferrell', 'pifal@mailinator.com', 'bcad905cdcfcc99afb999f08b4ad263a', 'whole sale'),
(5, 'nevada barker', 'votisopopa@mailinator.com', 'bcad905cdcfcc99afb999f08b4ad263a', 'whole sale'),
(6, 'gloria wolf', 'qehutebyt@mailinator.com', 'bcad905cdcfcc99afb999f08b4ad263a', 'whole sale');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `store`
--
ALTER TABLE `store`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `store` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
